import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import { env } from './config/env.js';
import { prisma } from './config/database.js';
import { authMiddleware, requireRole } from './middleware/auth.middleware.js';
import { authRoutes } from './api/routes/auth.routes.js';
import { clientsRoutes } from './api/routes/clients.routes.js';
import { subscriptionsRoutes } from './api/routes/subscriptions.routes.js';
import { invoicesRoutes } from './api/routes/invoices.routes.js';
import { n8nRoutes } from './api/routes/n8n.routes.js';
import { leadsRoutes } from './api/routes/leads.routes.js';
import { notificationsRoutes } from './api/routes/notifications.routes.js';
import { tenantRoutes } from './api/routes/tenant.routes.js';
import { usersRoutes } from './api/routes/users.routes.js';
import { logsRoutes } from './api/routes/logs.routes.js';
import { landingRoutes } from './api/routes/landing.routes.js';
import { agentRoutes } from './api/routes/agent.routes.js';
import { articleCodesRoutes } from './api/routes/article-codes.routes.js';
import { bonsCommandeRoutes } from './api/routes/bons-commande.routes.js';
import { devisRoutes } from './api/routes/devis.routes.js';
import { avoirRoutes } from './api/routes/avoir.routes.js';
import { proformaRoutes } from './api/routes/proforma.routes.js';
import { callLogsRoutes } from './api/routes/call-logs.routes.js';
import { twilioConfigRoutes } from './api/routes/twilio-config.routes.js';
import { smsRoutes } from './api/routes/sms.routes.js';
import { questionnairesRoutes } from './api/routes/questionnaires.routes.js';
import { comptabiliteRoutes } from './api/routes/comptabilite.routes.js';
import { clientSpacesRoutes } from './api/routes/client-spaces.routes.js';

// Créer l'instance Fastify
const fastify = Fastify({
  logger: {
    level: env.NODE_ENV === 'production' ? 'info' : 'debug',
    transport:
      env.NODE_ENV === 'development'
        ? {
            target: 'pino-pretty',
            options: {
              translateTime: 'HH:MM:ss Z',
              ignore: 'pid,hostname',
            },
          }
        : undefined,
  },
});

// Déclarer les types pour TypeScript
declare module 'fastify' {
  interface FastifyInstance {
    authenticate: typeof authMiddleware;
    requireRole: typeof requireRole;
  }
}

// Plugins de sécurité
await fastify.register(helmet, {
  contentSecurityPolicy: false, // Désactivé car on gère CORS séparément
});

// CORS - Autoriser uniquement le domaine frontend
await fastify.register(cors, {
  origin: env.NODE_ENV === 'production' 
    ? (env.CORS_ORIGIN || 'https://talosprimes.com') // Une seule origine (sans virgule)
    : true, // En dev, autoriser tout
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-TalosPrimes-N8N-Secret'],
});

// Rate limiting
await fastify.register(rateLimit, {
  max: 100, // 100 requêtes
  timeWindow: '1 minute', // par minute
});

// Route de santé (health check)
fastify.get('/health', async () => {
  // Vérifier la connexion DB
  try {
    await prisma.$queryRaw`SELECT 1`;
    return { status: 'ok', database: 'connected' };
  } catch (error) {
    fastify.log.error(error, 'Database connection failed');
    return { status: 'error', database: 'disconnected' };
  }
});

// Décorer Fastify avec les middlewares d'authentification
fastify.decorate('authenticate', authMiddleware);
fastify.decorate('requireRole', requireRole);

// Enregistrer les routes d'authentification
await fastify.register(async (fastify) => {
  await fastify.register(authRoutes, { prefix: '/api/auth' });
});

// Enregistrer les routes clients finaux
await fastify.register(async (fastify) => {
  await fastify.register(clientsRoutes, { prefix: '/api/clients' });
});

// Enregistrer les routes abonnements
await fastify.register(async (fastify) => {
  await fastify.register(subscriptionsRoutes, { prefix: '/api/subscriptions' });
});

// Enregistrer les routes factures
await fastify.register(async (fastify) => {
  await fastify.register(invoicesRoutes, { prefix: '/api/invoices' });
});

// Enregistrer les routes n8n (admin uniquement)
await fastify.register(async (fastify) => {
  await fastify.register(n8nRoutes, { prefix: '/api/n8n' });
});

// Enregistrer les routes leads (public pour création, admin pour consultation)
await fastify.register(async (fastify) => {
  await fastify.register(leadsRoutes, { prefix: '/api/leads' });
});

// Enregistrer les routes tenant (profil entreprise)
await fastify.register(async (fastify) => {
  await fastify.register(tenantRoutes, { prefix: '/api/tenant' });
});

// Enregistrer les routes users (gestion utilisateurs)
await fastify.register(async (fastify) => {
  await fastify.register(usersRoutes, { prefix: '/api/users' });
});

// Enregistrer les routes notifications
await fastify.register(async (fastify) => {
  await fastify.register(notificationsRoutes, { prefix: '/api/notifications' });
});

// Enregistrer les routes logs
await fastify.register(async (fastify) => {
  await fastify.register(logsRoutes, { prefix: '/api/logs' });
});

// Enregistrer les routes landing (public + admin)
await fastify.register(async (fastify) => {
  await fastify.register(landingRoutes);
});

// Enregistrer les routes agent IA (chat super-assistant)
await fastify.register(async (fastify) => {
  await fastify.register(agentRoutes, { prefix: '/api/agent' });
});

// Enregistrer les routes codes articles
await fastify.register(async (fastify) => {
  await fastify.register(articleCodesRoutes, { prefix: '/api/article-codes' });
});

// Enregistrer les routes bons de commande
await fastify.register(async (fastify) => {
  await fastify.register(bonsCommandeRoutes, { prefix: '/api/bons-commande' });
  await fastify.register(devisRoutes, { prefix: '/api/devis' });
});

// Enregistrer les routes avoirs
await fastify.register(async (fastify) => {
  await fastify.register(avoirRoutes, { prefix: '/api/avoirs' });
});

// Enregistrer les routes proformas
await fastify.register(async (fastify) => {
  await fastify.register(proformaRoutes, { prefix: '/api/proformas' });
});

// Enregistrer les routes call logs
await fastify.register(async (fastify) => {
  await fastify.register(callLogsRoutes, { prefix: '/api/call-logs' });
});

// Enregistrer les routes twilio config
await fastify.register(async (fastify) => {
  await fastify.register(twilioConfigRoutes, { prefix: '/api/twilio-config' });
});

// Enregistrer les routes SMS
await fastify.register(async (fastify) => {
  await fastify.register(smsRoutes, { prefix: '/api/sms' });
});

// Enregistrer les routes questionnaires
await fastify.register(async (fastify) => {
  await fastify.register(questionnairesRoutes, { prefix: '/api/questionnaires' });

  // Comptabilité
  await fastify.register(comptabiliteRoutes, { prefix: '/api/comptabilite' });
});

// Enregistrer les routes espaces clients
await fastify.register(async (fastify) => {
  await fastify.register(clientSpacesRoutes, { prefix: '/api/client-spaces' });
});

// Route de test
fastify.get('/', async () => {
  return { 
    message: 'TalosPrimes API',
    version: '0.1.0',
    status: 'running',
  };
});

// Démarrer le serveur
const start = async () => {
  try {
    await fastify.listen({ 
      port: env.PORT, 
      host: '0.0.0.0', // Écouter sur toutes les interfaces (important pour Docker/production)
    });
    
    fastify.log.info(`🚀 Server running on http://0.0.0.0:${env.PORT}`);
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
};

// Gestion propre de l'arrêt
process.on('SIGINT', async () => {
  fastify.log.info('Shutting down server...');
  await fastify.close();
  await prisma.$disconnect();
  process.exit(0);
});

start();

