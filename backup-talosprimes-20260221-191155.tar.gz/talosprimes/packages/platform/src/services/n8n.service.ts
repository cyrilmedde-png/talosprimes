import { env } from '../config/env.js';
import { prisma } from '../config/database.js';
import { eventService } from './event.service.js';

/**
 * Convertit récursivement les clés snake_case en camelCase.
 * Nécessaire car PostgreSQL renvoie des colonnes en snake_case
 * mais le frontend attend du camelCase (conventions TypeScript/React).
 */
function snakeToCamelKey(key: string): string {
  return key.replace(/_([a-z0-9])/g, (_, c) => c.toUpperCase());
}

function transformKeys(data: unknown): unknown {
  if (data === null || data === undefined) return data;
  if (Array.isArray(data)) return data.map(transformKeys);
  if (typeof data === 'object' && data !== null) {
    const result: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(data as Record<string, unknown>)) {
      result[snakeToCamelKey(key)] = transformKeys(value);
    }
    return result;
  }
  return data;
}

/**
 * Mapping des anciens workflowN8nId (underscore) vers les chemins webhook n8n (tiret).
 * Les workflows JSON utilisent path: "invoice-created", pas "invoice_create".
 */
const WEBHOOK_PATH_ALIASES: Record<string, string> = {
  // Factures
  invoice_create: 'invoice-created',
  invoice_send: 'invoice-sent',
  invoice_paid: 'invoice-paid',
  invoice_overdue: 'invoice-overdue',
  invoice_get: 'invoice-get',
  invoice_update: 'invoice-update',
  invoice_delete: 'invoice-deleted',
  invoice_generate_pdf: 'invoice-generate-pdf',
  invoices_list: 'invoices-list',
  // Abonnements
  subscription_renewal: 'subscription-renewal',
  subscription_cancelled: 'subscription-cancelled',
  subscription_suspended: 'subscription-suspended',
  subscription_upgrade: 'subscription-upgrade',
  // Clients
  client_create: 'client_create',
  client_create_from_lead: 'client_create_from_lead',
  client_delete: 'client_delete',
  client_get: 'client_get',
  client_update: 'client_update',
  clients_list: 'clients_list',
  client_deleted_cleanup_lead: 'client-deleted-cleanup-lead',
  client_onboarding: 'client-onboarding',
  stripe_checkout_completed: 'stripe-checkout-completed',
  // Leads
  lead_create: 'lead_create',
  leads_list: 'leads_list',
  lead_get: 'lead_get',
  lead_delete: 'lead_delete',
  lead_update_status: 'lead_update_status',
  lead_confirmation: 'lead_confirmation',
  lead_entretien: 'lead_entretien',
  lead_questionnaire: 'lead_questionnaire',
  lead_inscription: 'inscription',
  workflow_inscription: 'inscription',
  // Codes articles
  article_codes_list: 'article-codes-list',
  article_code_create: 'article-code-created',
  article_code_update: 'article-code-updated',
  article_code_delete: 'article-code-deleted',
  // Devis
  devis_list: 'devis-list',
  devis_get: 'devis-get',
  devis_create: 'devis-created',
  devis_send: 'devis-sent',
  devis_accept: 'devis-accepted',
  devis_convert_to_invoice: 'devis-convert-to-invoice',
  devis_convert_to_bdc: 'devis-convert-to-bdc',
  devis_delete: 'devis-deleted',
  // Bons de commande
  bdc_list: 'bdc-list',
  bdc_get: 'bdc-get',
  bdc_create: 'bdc-created',
  bdc_validate: 'bdc-validated',
  bdc_convert_to_invoice: 'bdc-convert-to-invoice',
  bdc_delete: 'bdc-deleted',
  // Avoirs (notes de crédit)
  avoir_list: 'avoir-list',
  avoir_get: 'avoir-get',
  avoir_create: 'avoir-created',
  avoir_validate: 'avoir-validated',
  avoir_delete: 'avoir-deleted',
  invoice_convert_to_avoir: 'invoice-convert-to-avoir',
  // Proformas
  proforma_list: 'proforma-list',
  proforma_get: 'proforma-get',
  proforma_create: 'proforma-created',
  proforma_send: 'proforma-sent',
  proforma_accept: 'proforma-accepted',
  proforma_convert_to_invoice: 'proforma-convert-to-invoice',
  proforma_delete: 'proforma-deleted',
  // Logs
  logs_list: 'logs-list',
  logs_stats: 'logs-stats',
  // Notifications
  notifications_list: 'notifications-list',
  notification_create: 'notification-created',
  notification_read: 'notification-read',
  notification_delete: 'notification-deleted',
  // Call Logs
  call_log_list: 'call-log-list',
  call_log_get: 'call-log-get',
  call_log_stats: 'call-log-stats',
  call_log_create: 'call-log-create',
  call_log_update: 'call-log-update',
  call_log_delete: 'call-log-delete',
  // Twilio Config
  twilio_config_get: 'twilio-config-get',
  twilio_config_update: 'twilio-config-update',
  twilio_test_call: 'twilio-test-call',
  twilio_outbound_call: 'twilio-outbound-call',
  twilio_inbound_voice: 'twilio-inbound-voice',
  // SMS
  sms_list: 'sms-list',
  sms_stats: 'sms-stats',
  sms_send: 'sms-send',
  sms_log_create: 'sms-log-create',
  // Questionnaires
  questionnaire_list: 'questionnaire-list',
  questionnaire_get: 'questionnaire-get',
  questionnaire_create: 'questionnaire-create',
  questionnaire_update: 'questionnaire-update',
  questionnaire_delete: 'questionnaire-delete',
  // Comptabilité
  compta_init: 'compta-init',
  compta_plan_comptable_list: 'compta-plan-comptable-list',
  compta_ecriture_create: 'compta-ecriture-create',
  compta_ecritures_list: 'compta-ecritures-list',
  compta_ecriture_get: 'compta-ecriture-get',
  compta_auto_facture: 'compta-auto-facture',
  compta_auto_avoir: 'compta-auto-avoir',
  compta_auto_paiement: 'compta-auto-paiement',
  compta_grand_livre: 'compta-grand-livre',
  compta_balance: 'compta-balance',
  compta_bilan: 'compta-bilan',
  compta_compte_resultat: 'compta-compte-resultat',
  compta_tva: 'compta-tva',
  compta_lettrage: 'compta-lettrage',
  compta_cloture: 'compta-cloture',
  compta_dashboard: 'compta-dashboard',
  compta_ia_agent: 'compta-ia-agent',
  // Espaces clients
  client_space_create: 'client-space-create',
  client_space_validate: 'client-space-validate',
  client_space_list: 'client-space-list',
  client_space_get: 'client-space-get',
  client_space_resend_email: 'client-space-resend-email',
};

/**
 * Service pour communiquer avec n8n
 * Déclenche les workflows n8n selon les événements métiers
 */
export class N8nService {
  private apiUrl: string;
  private apiKey: string | undefined;
  private username: string | undefined;
  private password: string | undefined;

  /** Retourne le chemin webhook à appeler (compatible ancienne BDD ou nouvelle). */
  private getWebhookPath(storedWorkflowId: string): string {
    return WEBHOOK_PATH_ALIASES[storedWorkflowId] ?? storedWorkflowId;
  }

  constructor() {
    this.apiUrl = env.N8N_API_URL || '';
    this.apiKey = env.N8N_API_KEY;
    this.username = env.N8N_USERNAME;
    this.password = env.N8N_PASSWORD;

    if (!this.apiUrl) {
      console.warn('⚠️ N8N_API_URL non configuré - les workflows ne seront pas déclenchés');
    }
  }

  /**
   * Appelle un workflow n8n et retourne la réponse JSON
   * Utile pour les vues (listage/lecture) orchestrées par n8n
   * 
   * IMPORTANT: Les webhooks n8n sont PUBLICS par défaut et n'acceptent PAS d'authentification.
   * Si n8n a une authentification activée au niveau de l'instance, les webhooks peuvent être protégés,
   * mais dans ce cas, l'authentification se fait via query parameter ou autre méthode, pas via headers.
   */
  async callWorkflowReturn<T = unknown>(
    tenantId: string,
    eventType: string,
    payload: Record<string, unknown>
  ): Promise<{ success: boolean; data?: T; error?: string }> {
    if (!this.apiUrl) {
      return { success: false, error: 'n8n non configuré' };
    }

    try {
      const workflowLink = await prisma.workflowLink.findFirst({
        where: {
          tenantId,
          typeEvenement: eventType,
          statut: 'actif',
        },
      });

      if (!workflowLink) {
        return { success: false, error: `Workflow non trouvé pour ${eventType}` };
      }

      // IMPORTANT: Les webhooks n8n sont publics par défaut
      // Si votre instance n8n nécessite une authentification, vous devez :
      // 1. Soit désactiver l'authentification pour les webhooks dans n8n
      // 2. Soit utiliser l'API REST de n8n au lieu des webhooks
      // 3. Soit configurer n8n pour accepter les webhooks avec authentification
      
      // Pour l'instant, on n'envoie PAS d'headers d'authentification pour les webhooks
      // car les webhooks n8n sont publics par défaut
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };

      // Si n8n nécessite une authentification pour les webhooks (configuration spéciale),
      // vous pouvez décommenter ces lignes et configurer n8n en conséquence :
      // if (this.apiKey) {
      //   headers['X-N8N-API-KEY'] = this.apiKey;
      // } else if (this.username && this.password) {
      //   const credentials = Buffer.from(`${this.username}:${this.password}`).toString('base64');
      //   headers['Authorization'] = `Basic ${credentials}`;
      // }

      // Envoyer le payload à plat + dans data pour compatibilité avec tous les workflows
      // Nouveaux workflows (devis, bdc, proforma, notifications, logs) : lisent $input.body.tenantId, .page, etc.
      // Anciens workflows (clients, leads, invoices) : lisent payload.data.xxx avec fallback sur payload.xxx
      const webhookPath = this.getWebhookPath(workflowLink.workflowN8nId);
      const response = await fetch(`${this.apiUrl}/webhook/${webhookPath}`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          event: eventType,
          tenantId,
          timestamp: new Date().toISOString(),
          ...payload,     // champs à plat pour les nouveaux workflows
          data: payload,   // wrapper data pour les anciens workflows
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        return { success: false, error: `n8n API error: ${response.status} - ${errorText}` };
      }

      const rawData = await response.json().catch(() => ({}));
      // Convertir les clés snake_case (PostgreSQL) en camelCase (frontend)
      const data = transformKeys(rawData) as T;
      return { success: true, data };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      return { success: false, error: errorMessage };
    }
  }
  /**
   * Génère les headers d'authentification pour les requêtes n8n API REST
   * (pas pour les webhooks qui sont publics)
   */
  private getAuthHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    // Priorité 1 : API Key (si disponible)
    if (this.apiKey) {
      headers['X-N8N-API-KEY'] = this.apiKey;
      return headers;
    }

    // Priorité 2 : Basic Auth (username/password)
    if (this.username && this.password) {
      const credentials = Buffer.from(`${this.username}:${this.password}`).toString('base64');
      headers['Authorization'] = `Basic ${credentials}`;
      return headers;
    }

    // Pas d'authentification configurée
    return headers;
  }

  /**
   * Déclenche un workflow n8n pour un événement donné
   */
  async triggerWorkflow(
    tenantId: string,
    eventType: string,
    payload: Record<string, unknown>
  ): Promise<{ success: boolean; workflowId?: string; error?: string }> {
    // Si n8n n'est pas configuré, on log juste l'événement
    if (!this.apiUrl) {
      console.log(`[n8n] Événement non déclenché (n8n non configuré): ${eventType}`);
      return { success: false, error: 'n8n non configuré' };
    }

    try {
      // Récupérer le workflow lié à cet événement pour ce tenant
      const workflowLink = await prisma.workflowLink.findFirst({
        where: {
          tenantId,
          typeEvenement: eventType,
          statut: 'actif',
        },
        include: {
          moduleMetier: true,
        },
      });

      if (!workflowLink) {
        console.log(`[n8n] Aucun workflow actif trouvé pour l'événement: ${eventType} (tenant: ${tenantId})`);
        // Retourner success: true car c'est un cas normal (pas de workflow configuré pour cet événement)
        // Ne pas logger comme erreur pour éviter de polluer les logs avec des "erreurs" normales
        return { success: true, workflowId: undefined };
      }

      // Préparer le payload pour n8n — à plat + data wrapper pour compatibilité
      const n8nPayload = {
        event: eventType,
        tenantId,
        timestamp: new Date().toISOString(),
        ...payload,     // champs à plat pour les nouveaux workflows
        data: payload,   // wrapper data pour les anciens workflows
        metadata: {
          workflowId: workflowLink.workflowN8nId,
          workflowName: workflowLink.workflowN8nNom,
          module: workflowLink.moduleMetier.code,
        },
      };

      // IMPORTANT: Les webhooks n8n sont publics par défaut
      // On n'envoie PAS d'headers d'authentification pour les webhooks
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };

      // Appel à l'API n8n (webhook public) — chemin normalisé (invoice_create → invoice-created)
      const webhookPath = this.getWebhookPath(workflowLink.workflowN8nId);
      const response = await fetch(`${this.apiUrl}/webhook/${webhookPath}`, {
        method: 'POST',
        headers,
        body: JSON.stringify(n8nPayload),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`n8n API error: ${response.status} - ${errorText}`);
      }

      await response.json().catch(() => ({}));

      console.log(`[n8n] Workflow déclenché avec succès: ${workflowLink.workflowN8nNom} (${eventType})`);

      return {
        success: true,
        workflowId: workflowLink.workflowN8nId,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      console.error(`[n8n] Erreur lors du déclenchement du workflow (${eventType}):`, errorMessage);

      // Mettre à jour le statut de l'événement en erreur
      // On récupère le dernier EventLog pour cet événement
      const eventLog = await prisma.eventLog.findFirst({
        where: {
          tenantId,
          typeEvenement: eventType,
        },
        orderBy: {
          createdAt: 'desc',
        },
      });

      if (eventLog) {
        await eventService.updateEventStatus(
          eventLog.id,
          'erreur',
          undefined,
          errorMessage
        );
      }

      return {
        success: false,
        error: errorMessage,
      };
    }
  }

  /**
   * Teste la connexion à n8n
   */
  async testConnection(): Promise<{ success: boolean; message: string }> {
    if (!this.apiUrl) {
      return {
        success: false,
        message: 'N8N_API_URL non configuré',
      };
    }

    try {
      // Tester avec un endpoint de santé n8n (si disponible)
      const healthUrl = `${this.apiUrl.replace(/\/$/, '')}/healthz`;
      const response = await fetch(healthUrl, {
        method: 'GET',
        headers: this.getAuthHeaders(), // Pour l'API REST, on utilise l'authentification
      });

      if (response.ok) {
        return {
          success: true,
          message: 'Connexion à n8n réussie',
        };
      }

      return {
        success: false,
        message: `n8n répond mais avec une erreur: ${response.status}`,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      return {
        success: false,
        message: `Impossible de se connecter à n8n: ${errorMessage}`,
      };
    }
  }

  /**
   * Récupère la liste des workflows d'un tenant depuis n8n
   * (nécessite que n8n expose une API pour lister les workflows)
   */
  async listWorkflows(tenantId: string): Promise<Array<{ id: string; name: string }>> {
    if (!this.apiUrl) {
      return [];
    }

    try {
      // Cette méthode dépend de l'API n8n disponible
      // Si n8n expose une API REST pour lister les workflows, l'utiliser ici
      // Sinon, on se base sur la table WorkflowLink en DB

      const workflowLinks = await prisma.workflowLink.findMany({
        where: {
          tenantId,
          statut: 'actif',
        },
        select: {
          workflowN8nId: true,
          workflowN8nNom: true,
        },
      });

      return workflowLinks.map((link: any) => ({
        id: link.workflowN8nId,
        name: link.workflowN8nNom,
      }));
    } catch (error) {
      console.error('[n8n] Erreur lors de la récupération des workflows:', error);
      return [];
    }
  }
  /**
   * Publie tous les workflows n8n : active via API + docker restart.
   *
   * IMPORTANT (n8n bug #21614) : L'API REST de n8n (POST /activate, PATCH active:true)
   * marque les workflows comme "actifs" dans la DB mais N'ENREGISTRE PAS les webhooks.
   * Seul le bouton "Publish" de l'UI n8n enregistre les webhooks.
   *
   * WORKAROUND : Activer via API (met le flag active=true en DB) puis redémarrer n8n.
   * Au démarrage, n8n lit tous les workflows actifs et enregistre leurs webhooks.
   */
  async publishAllWorkflows(): Promise<{ success: boolean; message: string; count?: number }> {
    if (!this.apiUrl || !this.apiKey) {
      return { success: false, message: 'N8N_API_URL ou N8N_API_KEY non configuré' };
    }

    const baseUrl = this.apiUrl.replace(/\/$/, '');

    try {
      // 1. Lister TOUS les workflows (pas seulement les actifs)
      const allWorkflows: Array<{ id: string; name: string; active: boolean }> = [];
      let cursor = '';

      for (let page = 0; page < 20; page++) {
        const url = cursor
          ? `${baseUrl}/api/v1/workflows?limit=250&cursor=${cursor}`
          : `${baseUrl}/api/v1/workflows?limit=250`;

        const listResp = await fetch(url, {
          headers: { 'X-N8N-API-KEY': this.apiKey },
          signal: AbortSignal.timeout(15_000),
        });

        if (!listResp.ok) {
          return { success: false, message: `Erreur API n8n: HTTP ${listResp.status}` };
        }

        const listData = await listResp.json() as {
          data?: Array<{ id: string; name: string; active: boolean }>;
          nextCursor?: string;
        };
        const workflows = listData.data || [];
        allWorkflows.push(...workflows);

        cursor = listData.nextCursor || '';
        if (!cursor || workflows.length === 0) break;
      }

      // 2. Activer chaque workflow inactif via POST /activate (met le flag en DB)
      const inactiveWorkflows = allWorkflows.filter(wf => !wf.active);
      let successCount = 0;
      let errorCount = 0;

      for (const wf of inactiveWorkflows) {
        try {
          const resp = await fetch(`${baseUrl}/api/v1/workflows/${wf.id}/activate`, {
            method: 'POST',
            headers: { 'X-N8N-API-KEY': this.apiKey! },
            signal: AbortSignal.timeout(10_000),
          });
          if (resp.ok) {
            successCount++;
          } else {
            errorCount++;
            console.warn(`[n8n] Échec activation workflow ${wf.id} (${wf.name}): HTTP ${resp.status}`);
          }
        } catch {
          errorCount++;
        }
      }

      const alreadyActive = allWorkflows.length - inactiveWorkflows.length;
      const totalActive = alreadyActive + successCount;

      // 3. Redémarrer n8n pour enregistrer les webhooks
      // Le restart est OBLIGATOIRE car l'API ne register pas les webhooks (bug #21614)
      console.log('[n8n] Redémarrage de n8n pour enregistrer les webhooks...');

      const { exec } = await import('child_process');
      const { promisify } = await import('util');
      const execAsync = promisify(exec);

      try {
        await execAsync('docker restart n8n', { timeout: 30_000 });
      } catch (restartErr) {
        console.error('[n8n] Erreur docker restart:', restartErr);
        return {
          success: false,
          message: `${totalActive}/${allWorkflows.length} workflows activés en DB mais docker restart échoué — webhooks non enregistrés`,
          count: totalActive,
        };
      }

      // 4. Attendre que n8n soit prêt (health check)
      let n8nReady = false;
      for (let i = 0; i < 30; i++) {
        try {
          const healthResp = await fetch(`${baseUrl}/healthz`, {
            signal: AbortSignal.timeout(3_000),
          });
          if (healthResp.ok) {
            n8nReady = true;
            break;
          }
        } catch { /* n8n pas encore prêt */ }
        await new Promise(resolve => setTimeout(resolve, 2_000));
      }

      if (!n8nReady) {
        return {
          success: true,
          message: `${totalActive}/${allWorkflows.length} workflows activés, n8n redémarré mais health check échoué — vérifier manuellement`,
          count: totalActive,
        };
      }

      const message = errorCount > 0
        ? `${totalActive}/${allWorkflows.length} workflows publiés (${errorCount} erreurs d'activation, ${alreadyActive} déjà actifs) — webhooks enregistrés`
        : `${totalActive}/${allWorkflows.length} workflows publiés — webhooks enregistrés`;

      return { success: true, message, count: totalActive };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue';
      return { success: false, message: `Erreur: ${errorMessage}` };
    }
  }
}

export const n8nService = new N8nService();
