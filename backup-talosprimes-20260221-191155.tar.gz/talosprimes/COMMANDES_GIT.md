# Commandes Git à exécuter

## 🚀 Commandes rapides (copier-coller)

**Assurez-vous d'être dans le bon dossier :**
```bash
cd "/Users/giiz_mo_o/Desktop/devellopement application/talosprimes"
```

**1. Initialiser Git :**
```bash
git init
```

**2. Configurer votre identité (une seule fois) :**
```bash
git config user.name "Votre Nom"
git config user.email "votre.email@example.com"
```

**3. Vérifier que .env est ignoré :**
```bash
git check-ignore -v packages/platform/.env || echo "⚠️ .env n'est PAS ignoré!"
```

**4. Ajouter tous les fichiers :**
```bash
git add .
```

**5. Vérifier ce qui va être commité :**
```bash
git status
```

**6. Premier commit :**
```bash
git commit -m "Initial commit: Architecture complète avec Fastify, Next.js, Prisma et Supabase"
```

**7. Ajouter le remote GitHub (remplacez VOTRE_USERNAME) :**

**Option A - SSH (recommandé, nécessite une clé SSH configurée) :**
```bash
git remote add origin git@github.com:VOTRE_USERNAME/talosprimes.git
```

**Option B - HTTPS (nécessite un Personal Access Token) :**
```bash
git remote add origin https://github.com/VOTRE_USERNAME/talosprimes.git
```

> 💡 **Pour créer une clé SSH**, voir [GITHUB_SSH_KEY.md](./GITHUB_SSH_KEY.md)

**8. Renommer la branche en 'main' :**
```bash
git branch -M main
```

**9. Pousser sur GitHub :**
```bash
git push -u origin main
```

## 📝 Après avoir créé le repo sur GitHub

1. Allez sur [github.com/new](https://github.com/new)
2. Nom : `talosprimes`
3. **Ne cochez PAS** "Initialize with README"
4. Créez le repo
5. **Puis exécutez les commandes ci-dessus**

## 🔐 Authentification GitHub

### Option 1 : Clé SSH (Recommandée)

Suivez le guide : [GITHUB_SSH_KEY.md](./GITHUB_SSH_KEY.md)

Une fois configuré, utilisez l'URL SSH : `git@github.com:VOTRE_USERNAME/talosprimes.git`

### Option 2 : Personal Access Token

Si GitHub vous demande un mot de passe (avec HTTPS) :
1. Allez sur [github.com/settings/tokens](https://github.com/settings/tokens)
2. Generate new token (classic)
3. Cochez `repo`
4. Generate
5. **Copiez le token** et utilisez-le comme mot de passe lors du `git push`

