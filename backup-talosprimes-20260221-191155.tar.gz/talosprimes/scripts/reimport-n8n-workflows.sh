#!/bin/bash

################################################################################
# N8N Workflow Reimporter - TalosPrimes
################################################################################
# Reimports n8n workflows from JSON backup files, updating broken workflows
# that have empty Code nodes with full implementations from backups.
#
# Features:
# - Finds existing workflow IDs by matching webhook paths
# - Replaces old credential IDs with current n8n instance credentials
# - Updates workflows via PUT /api/v1/workflows/{id}
# - Activates workflows after successful import
# - Comprehensive logging and error handling
#
# Usage:
#   ./scripts/reimport-n8n-workflows.sh [API_KEY] [N8N_URL]
#   ./scripts/reimport-n8n-workflows.sh                    (uses .env)
#
# Environment Variables:
#   N8N_API_KEY     - n8n API key (required)
#   N8N_API_URL     - n8n API endpoint (default: http://localhost:5678)
#   ENV_FILE        - Path to .env file (default: packages/platform/.env)
#
# Examples:
#   ./scripts/reimport-n8n-workflows.sh
#   ./scripts/reimport-n8n-workflows.sh "my-api-key" "https://n8n.example.com"
#   N8N_API_KEY="my-key" ./scripts/reimport-n8n-workflows.sh
#
################################################################################

set -euo pipefail

# ============================================================================
# Configuration
# ============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
BACKUP_DIR="${PROJECT_DIR}/n8n_workflows/talosprimes"
PLATFORM_DIR="${PROJECT_DIR}/packages/platform"
LOG_FILE="${SCRIPT_DIR}/../reimport-workflows-$(date +%Y%m%d_%H%M%S).log"
TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")

# Credential ID mappings (current n8n instance) — extracted from live workflows
declare -A CREDENTIAL_MAP=(
    # Postgres / Supabase
    ["postgres"]="6Kosza77d9Ld32mw"
    ["Supabase Postgres"]="6Kosza77d9Ld32mw"
    ["Postgres account"]="6Kosza77d9Ld32mw"
    # TalosPrimes API (2 variantes)
    ["TalosPrimes API Auth"]="AuJmz6W8aeutvysV"
    ["httpHeaderAuth:talosprimes"]="AuJmz6W8aeutvysV"
    ["API TalosPrimes - Header Auth"]="FLSZWCszgEFfXDoK"
    ["API TalosPrimes"]="FLSZWCszgEFfXDoK"
    ["TalosPrimes API"]="FLSZWCszgEFfXDoK"
    ["talosprimes-api-credential"]="FLSZWCszgEFfXDoK"
    # Resend (email)
    ["RESEND"]="ZoJkKnTqGisK2Idh"
    ["Resend API"]="ZoJkKnTqGisK2Idh"
    ["httpHeaderAuth:resend"]="ZoJkKnTqGisK2Idh"
    ["resend-api-credential"]="ZoJkKnTqGisK2Idh"
    # Stripe
    ["Stripe API"]="hTgbVXtv3dG8wSJ4"
    # Twilio
    ["twilio"]="9dKAFunSg4lJcj77"
    ["Twilio account"]="9dKAFunSg4lJcj77"
    # n8n API
    ["n8nApi"]="soHoxOtlUU9xdHDu"
    ["n8n API Key"]="soHoxOtlUU9xdHDu"
    ["X-N8N-API-KEY"]="soHoxOtlUU9xdHDu"
    # Telegram
    ["Telegram account"]="JeSjY5sE3QcncJ4u"
    ["TeleGram Perso"]="D6qAvZZV2lhH6rVh"
    # OpenAI
    ["OpenAi account"]="MmpYHYAt746xfTrB"
    ["OpenAI API Key (Header)"]="openai-api-key-header"
    # Anthropic
    ["Anthropic account"]="SB3snedx3T9F5Tuz"
    # Gmail
    ["Gmail account"]="jzveDrdzJcs9iv7R"
    # Google Calendar
    ["Google Calendar account"]="1098OxGMJM5eG3PU"
    # SSH VPS
    ["SSH VPS TalosPrimes"]="b7jMAjh1KJcIwqdo"
    # SMTP
    ["SMTP TalosPrimes"]="hepAQJGA9ubd1NF4"
)

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Statistics
TOTAL_WORKFLOWS=0
SUCCESSFUL_UPDATES=0
FAILED_UPDATES=0
SKIPPED_WORKFLOWS=0

# ============================================================================
# Functions
# ============================================================================

# Log function with timestamp and colors
log() {
    local level="$1"
    shift
    local message="$*"
    local color=""

    case "$level" in
        "INFO") color="$BLUE" ;;
        "SUCCESS") color="$GREEN" ;;
        "WARN") color="$YELLOW" ;;
        "ERROR") color="$RED" ;;
        *) color="$NC" ;;
    esac

    echo -e "${color}[${TIMESTAMP}] [${level}]${NC} ${message}" | tee -a "$LOG_FILE"
}

# Print section header
header() {
    local title="$1"
    echo "" | tee -a "$LOG_FILE"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | tee -a "$LOG_FILE"
    echo -e "${BLUE}${title}${NC}" | tee -a "$LOG_FILE"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}" | tee -a "$LOG_FILE"
}

# Validate required tools
validate_tools() {
    local required_tools=("curl" "python3" "jq")
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" &> /dev/null; then
            log "ERROR" "Required tool not found: $tool"
            exit 1
        fi
    done
    log "SUCCESS" "All required tools are available"
}

# Load API key from .env if not provided
load_api_key() {
    if [ -n "${N8N_API_KEY:-}" ]; then
        log "INFO" "Using N8N_API_KEY from environment"
        return 0
    fi

    if [ -f "$PLATFORM_DIR/.env" ]; then
        log "INFO" "Loading N8N_API_KEY from $PLATFORM_DIR/.env"
        N8N_API_KEY=$(grep -E '^N8N_API_KEY=' "$PLATFORM_DIR/.env" 2>/dev/null | cut -d'=' -f2- | tr -d '"' | tr -d "'" || echo "")
        if [ -n "$N8N_API_KEY" ]; then
            export N8N_API_KEY
            return 0
        fi
    fi

    log "ERROR" "N8N_API_KEY not found. Please provide it via:"
    log "ERROR" "  - Command argument: ./script.sh 'API_KEY'"
    log "ERROR" "  - Environment variable: export N8N_API_KEY='...'"
    log "ERROR" "  - Or add N8N_API_KEY to $PLATFORM_DIR/.env"
    return 1
}

# Validate n8n connection
validate_n8n_connection() {
    log "INFO" "Testing connection to n8n at $N8N_API_URL..."

    local response
    response=$(curl -s -w "\n%{http_code}" -H "X-N8N-API-KEY: $N8N_API_KEY" "$N8N_API_URL/api/v1/workflows" 2>&1)
    local http_code
    http_code=$(echo "$response" | tail -1)

    if [ "$http_code" -eq 200 ]; then
        log "SUCCESS" "Connection successful (HTTP $http_code)"
        return 0
    else
        log "ERROR" "Failed to connect to n8n (HTTP $http_code)"
        log "ERROR" "Response: $(echo "$response" | head -1)"
        return 1
    fi
}

# Temp file for workflows cache
export WORKFLOWS_CACHE="/tmp/n8n_workflows_cache_$$.json"

# Cleanup on exit
cleanup() {
    rm -f "$WORKFLOWS_CACHE"
}
trap cleanup EXIT

# Fetch all workflows from n8n API into temp file
fetch_all_workflows() {
    log "INFO" "Fetching all workflows from n8n..."

    curl -s -H "X-N8N-API-KEY: $N8N_API_KEY" \
        "$N8N_API_URL/api/v1/workflows?limit=250" > "$WORKFLOWS_CACHE" 2>/dev/null

    local count
    count=$(python3 -c "import json; print(len(json.load(open('$WORKFLOWS_CACHE')).get('data',[])))" 2>/dev/null || echo "0")
    log "INFO" "Found $count workflows in n8n"

    if [ "$count" -eq 0 ]; then
        log "ERROR" "No workflows found - check API key and connection"
        return 1
    fi
    return 0
}

# Find workflow ID by webhook path (reads from cache file)
# Tries exact match first, then underscore/hyphen variants
find_workflow_by_webhook() {
    local webhook_path="$1"

    export WEBHOOK_PATH="$webhook_path"
    python3 << 'PYEOF'
import json, os

webhook_path = os.environ.get('WEBHOOK_PATH', '')
cache_file = os.environ.get('WORKFLOWS_CACHE', '')

with open(cache_file, 'r') as f:
    data = json.load(f)

# Build path variants: try hyphen, underscore, and original
variants = {
    webhook_path,
    webhook_path.replace('-', '_'),
    webhook_path.replace('_', '-'),
}

# Strategy 1: Match by webhook path (with variants)
for workflow in data.get('data', []):
    for node in workflow.get('nodes', []):
        if node.get('type') == 'n8n-nodes-base.webhook':
            node_path = node.get('parameters', {}).get('path', '')
            if node_path in variants:
                print(workflow.get('id', ''))
                exit(0)

# Strategy 2: Match by workflow name (handles edge cases like inscription)
name_variants = {
    webhook_path.lower(),
    webhook_path.replace('-', '_').lower(),
    webhook_path.replace('_', '-').lower(),
}
for workflow in data.get('data', []):
    wf_name = workflow.get('name', '').lower().strip()
    if wf_name in name_variants:
        print(workflow.get('id', ''))
        exit(0)

print('')
PYEOF
}

# Get existing workflow's credential configuration from n8n (keyed by node name)
get_existing_credentials() {
    local workflow_id="$1"

    export WF_ID="$workflow_id"
    python3 << 'PYEOF'
import json, os

cache_file = os.environ.get('WORKFLOWS_CACHE', '')
wf_id = os.environ.get('WF_ID', '')

with open(cache_file, 'r') as f:
    data = json.load(f)

# Find the workflow by ID and extract credential config per node
creds = {}
for workflow in data.get('data', []):
    if str(workflow.get('id', '')) == wf_id:
        for node in workflow.get('nodes', []):
            node_creds = node.get('credentials', {})
            if node_creds:
                creds[node.get('name', '')] = node_creds
                # Also map by node type for fallback matching
                creds['__type__' + node.get('type', '')] = node_creds
        break

print(json.dumps(creds))
PYEOF
}

# Replace credential IDs in workflow JSON
# $1 = backup JSON file path
# $2 = existing credentials JSON (from get_existing_credentials)
replace_credentials_in_workflow() {
    local backup_json="$1"
    local existing_creds="${2:-{}}"

    export BACKUP_FILE="$backup_json"
    export EXISTING_CREDS="$existing_creds"
    python3 << 'PYEOF'
import json, os

backup_file = os.environ.get('BACKUP_FILE', '')
existing_creds_str = os.environ.get('EXISTING_CREDS', '{}')

with open(backup_file, 'r') as f:
    workflow = json.load(f)

# Parse existing credentials from n8n (already working in production)
try:
    existing_creds = json.loads(existing_creds_str)
except:
    existing_creds = {}

# Fallback credential mappings (only used if no existing creds found)
cred_map = {
    "postgres": "6Kosza77d9Ld32mw",
    "Supabase Postgres": "6Kosza77d9Ld32mw",
    "httpHeaderAuth:talosprimes": "AuJmz6W8aeutvysV",
    "TalosPrimes API Auth": "AuJmz6W8aeutvysV",
    "httpHeaderAuth:resend": "ZoJkKnTqGisK2Idh",
    "RESEND": "ZoJkKnTqGisK2Idh",
    "twilio": "9dKAFunSg4lJcj77",
    "Twilio account": "9dKAFunSg4lJcj77",
    "n8nApi": "soHoxOtlUU9xdHDu",
    "n8n API Key": "soHoxOtlUU9xdHDu",
    "X-N8N-API-KEY": "soHoxOtlUU9xdHDu",
    "API TalosPrimes - Header Auth": "FLSZWCszgEFfXDoK",
    "API TalosPrimes": "FLSZWCszgEFfXDoK",
    "TalosPrimes API": "FLSZWCszgEFfXDoK",
    "talosprimes-api-credential": "FLSZWCszgEFfXDoK",
    "Stripe API": "hTgbVXtv3dG8wSJ4",
    "Resend API": "ZoJkKnTqGisK2Idh",
    "resend-api-credential": "ZoJkKnTqGisK2Idh",
    "Telegram account": "JeSjY5sE3QcncJ4u",
    "TeleGram Perso": "D6qAvZZV2lhH6rVh",
    "OpenAi account": "MmpYHYAt746xfTrB",
    "OpenAI API Key (Header)": "openai-api-key-header",
    "Anthropic account": "SB3snedx3T9F5Tuz",
    "Gmail account": "jzveDrdzJcs9iv7R",
    "Google Calendar account": "1098OxGMJM5eG3PU"
}

# ---- Step 1: Find Parser node name dynamically ----
parser_node_name = None
nodes = workflow.get('nodes', [])
for node in nodes:
    name = node.get('name', '')
    if 'parser' in name.lower():
        parser_node_name = name
        break

# ---- Step 2: Process each node ----
for node in nodes:
    # Fix Code nodes: rename 'code' -> 'jsCode' AND fix $input.body references
    if node.get('type') == 'n8n-nodes-base.code':
        params = node.get('parameters', {})
        if 'code' in params and 'jsCode' not in params:
            params['jsCode'] = params.pop('code')
        js = params.get('jsCode', '')
        if js:
            import re
            # Fix old-style $input.body -> $input.first().json.body
            if '$input.body' in js:
                js = js.replace('$input.body', '$input.first().json.body')
            # Fix $('NodeName').all() -> .all().map(item => item.json)
            # Unwrap n8n item wrappers so responses return clean data
            js = re.sub(r"\$\('([^']+)'\)\.all\(\)(?!\.map)", r"$('\1').all().map(item => item.json)", js)
            # Fix $('NodeName').first() assigned to variable -> .first().json
            # e.g. const x = $('Node').first(); -> const x = $('Node').first().json;
            js = re.sub(r"\$\('([^']+)'\)\.first\(\)(?=\s*[;,\)])", r"$('\1').first().json", js)
            # Fix $('NodeName').first().field -> .first().json.field (inline usage)
            # In n8n, .first() returns an item with a .json property
            js = re.sub(r"\$\('([^']+)'\)\.first\(\)\.(?!json\b)(\w+)", r"$('\1').first().json.\2", js)
            # Fix $json.lines in ALL Code nodes -> Parser reference
            # 'lines' always comes from the Parser/webhook input, never from Postgres output
            node_name = node.get('name', '').lower()
            if parser_node_name and '$json.lines' in js:
                js = js.replace('$json.lines', "$('{}').first().json.lines".format(parser_node_name))
            # Fix $json.page/limit/offset in Format Response nodes
            # These reference Parser data, not the previous connected node
            if parser_node_name and ('format' in node_name or 'response' in node_name):
                for field in ['page', 'limit', 'offset']:
                    js = js.replace('$json.' + field, "$('{}').first().json.{}".format(parser_node_name, field))
            # Code nodes MUST return items in n8n v2
            # If no return statement, add passthrough to avoid "doesn't return items properly"
            if 'return ' not in js and 'return\n' not in js:
                js = js.rstrip() + '\nreturn $input.all();'
            params['jsCode'] = js

    # Fix Postgres nodes
    if node.get('type') == 'n8n-nodes-base.postgres':
        params = node.get('parameters', {})
        query = params.get('query', '')
        if query:
            import re
            skip_json_replace = False
            # ---- Jinja syntax handling (MUST be done BEFORE $json replacement) ----
            # Strip {% if %}...{% endif %} blocks (e.g. bdc-get conditional AND FALSE)
            query = re.sub(r'\{%\s*if\s+[^%]*%\}.*?\{%\s*endif\s*%\}', '', query, flags=re.DOTALL)
            # Convert {% for %} loops to JavaScript .map().join() expressions
            if '{%' in query and 'for' in query:
                if 'bon_commande_lines' in query:
                    # bdc-created: Insert Lines - use explicit node refs to avoid $json confusion
                    pn = "08. Prepare Lines"
                    ref = "$('{}').first().json".format(pn)
                    parts = []
                    parts.append("={{ " + ref + ".lines && " + ref + ".lines.length > 0")
                    parts.append(" ? " + ref + '.lines.map((line, idx) => ')
                    parts.append('"INSERT INTO bon_commande_lines (id, bon_commande_id, code_article, designation, quantite, prix_unitaire_ht, total_ht, ordre) VALUES (gen_random_uuid(), ')
                    parts.append("'\" + " + ref + ".bonId + \"', \" + ")
                    parts.append('(line.codeArticle ? "\'" + line.codeArticle + "\'" : "null") + ", ')
                    parts.append("'\" + (line.designation || '') + \"', \" + ")
                    parts.append('(line.quantite || 0) + ", " + (line.prixUnitaireHt || 0) + ", " + (line.totalHt || 0) + ", " + idx + ")"')
                    parts.append(').join("; ") + "; SELECT 1" : "SELECT 1" }}')
                    query = ''.join(parts)
                    skip_json_replace = True
                elif 'avoir_lines' in query:
                    # avoir-created: Insert Lines
                    query = '={{ $json.lineQueries && $json.lineQueries.length > 0 ? "INSERT INTO avoir_lines (avoir_id, ordre, code_article, designation, quantite, prix_unitaire_ht, total_ht) VALUES " + $json.lineQueries.map(item => "(\'" + item.avoirId + "\', " + item.ordre + ", \'" + (item.codeArticle || \'\') + "\', \'" + (item.designation || \'\') + "\', " + item.quantite + ", " + item.prixUnitaireHt + ", " + item.totalHt + ")").join(", ") : "SELECT 1" }}'
                    skip_json_replace = True
            # Convert each(item) pseudo-syntax to JavaScript .map().join() expressions
            # each(item) is NOT valid n8n - it was used as a placeholder for per-item iteration
            if 'each(item)' in query:
                if 'devis_lines' in query:
                    # devis-created: iterate lineInserts from "08. Prepare Lines"
                    ref = "$('08. Prepare Lines').first().json"
                    query = '={{ ' + ref + '.lineInserts && ' + ref + '.lineInserts.length > 0 ? ' + ref + ".lineInserts.map(item => \"INSERT INTO devis_lines (id, devis_id, code_article, designation, quantite, prix_unitaire_ht, total_ht, ordre) VALUES (gen_random_uuid(), '\" + item.devisId + \"', \" + (item.codeArticle ? \"'\" + item.codeArticle + \"'\" : \"null\") + \", '\" + (item.designation || item.description || '') + \"', \" + (item.quantite || 0) + \", \" + (item.prixUnitaireHt || item.prixUnitaire || 0) + \", \" + (item.totalHt || item.montantHt || 0) + \", \" + (item.ordre || item.ligneNumero || 0) + \")\").join(\"; \") + \"; SELECT 1\" : \"SELECT 1\" }}"
                    skip_json_replace = True
                elif 'proforma_lines' in query:
                    # proforma-created: iterate lineInserts from "08. Prepare Lines"
                    ref = "$('08. Prepare Lines').first().json"
                    query = '={{ ' + ref + '.lineInserts && ' + ref + '.lineInserts.length > 0 ? ' + ref + ".lineInserts.map(item => \"INSERT INTO proforma_lines (id, proforma_id, code_article, designation, quantite, prix_unitaire_ht, total_ht, ordre) VALUES (gen_random_uuid(), '\" + item.proformaId + \"', \" + (item.codeArticle ? \"'\" + item.codeArticle + \"'\" : \"null\") + \", '\" + (item.designation || item.description || '') + \"', \" + (item.quantite || 0) + \", \" + (item.prixUnitaireHt || item.prixUnitaire || 0) + \", \" + (item.totalHt || item.montantHt || 0) + \", \" + (item.ordre || item.ligneNumero || 0) + \")\").join(\"; \") + \"; SELECT 1\" : \"SELECT 1\" }}"
                    skip_json_replace = True
                elif 'invoice_lines' in query:
                    # convert-to-invoice: iterate lines from "10. Prepare Lines"
                    ref = "$('10. Prepare Lines').first().json"
                    query = '={{ ' + ref + '.lines && ' + ref + '.lines.length > 0 ? ' + ref + ".lines.map(item => \"INSERT INTO invoice_lines (id, invoice_id, code_article, designation, quantite, prix_unitaire_ht, total_ht, ordre) VALUES (gen_random_uuid(), '\" + " + ref + ".invoiceId + \"', \" + (item.code_article ? \"'\" + item.code_article + \"'\" : \"null\") + \", '\" + (item.designation || '') + \"', \" + (item.quantite || 0) + \", \" + (item.prix_unitaire_ht || 0) + \", \" + (item.total_ht || 0) + \", \" + (item.ordre || 0) + \")\").join(\"; \") + \"; SELECT 1\" : \"SELECT 1\" }}"
                    skip_json_replace = True
            # Replace $json. with explicit Parser reference (skip if loop/each was converted)
            if '$json.' in query and parser_node_name and not skip_json_replace:
                explicit_ref = "$('{}').first().json.".format(parser_node_name)
                query = query.replace('$json.', explicit_ref)
            # Fix $('NodeName').first().field -> .first().json.field in Postgres expressions
            query = re.sub(r"\$\('([^']+)'\)\.first\(\)\.(?!json\b)(\w+)", r"$('\1').first().json.\2", query)
            # Fix schema mismatches
            # Notifications table has NO updated_at column
            if 'notifications' in query and 'updated_at' in query:
                import re
                # Fix UPDATE SET clause first: remove ', updated_at = NOW()'
                query = re.sub(r',\s*updated_at\s*=\s*NOW\(\)', '', query)
                # Fix INSERT: remove updated_at from column list and NOW() from values
                query = re.sub(r',\s*updated_at\)', ')', query)
                query = re.sub(r",\s*NOW\(\)\)\s*RETURNING", ') RETURNING', query)
                # Fix SELECT/RETURNING: remove ', updated_at' from column lists
                query = query.replace(', updated_at', '')
            # Fix table name: bon_commandes -> bons_commande
            if 'bon_commandes' in query:
                query = query.replace('bon_commandes', 'bons_commande')
            # Generic fix: add id = gen_random_uuid() to any INSERT missing it
            # All TalosPrimes tables use UUID primary keys generated by the app
            if 'INSERT INTO' in query and 'gen_random_uuid' not in query:
                import re
                # Match INSERT INTO tablename (col1, col2, ...) and check if 'id' is first column
                insert_match = re.match(r"(=?INSERT INTO\s+\w+\s*\()(\s*\w+)", query)
                if insert_match and insert_match.group(2).strip() != 'id':
                    # Add 'id' as first column
                    query = query.replace(insert_match.group(0), insert_match.group(1) + 'id, ' + insert_match.group(2).strip())
                    # Add gen_random_uuid() as first value
                    values_match = re.search(r"VALUES\s*\(", query)
                    if values_match:
                        query = query[:values_match.end()] + "gen_random_uuid(), " + query[values_match.end():]
            # Fix proforma alias: FROM proformas d -> FROM proformas p
            if 'FROM proformas d ' in query:
                query = query.replace('FROM proformas d ', 'FROM proformas p ')
            # Fix event_logs column names (backup vs actual DB schema)
            # Only rename SQL column names, NOT JS property refs (preceded by '.')
            if 'event_logs' in query:
                import re
                # workflow -> workflow_n8n_id (SQL column only, not .json.workflow)
                query = re.sub(r'(?<!\.)workflow\b(?!_n8n)', 'workflow_n8n_id', query)
                # message -> message_erreur (SQL column only, not .json.message)
                query = re.sub(r'(?<!\.)message\b(?!_erreur)', 'message_erreur', query)
                # metadata -> payload (SQL column only)
                query = re.sub(r'(?<!\.)metadata\b', 'payload', query)
                # updated_at doesn't exist in event_logs
                query = query.replace(', updated_at', '')
            params['query'] = query

    # Replace credential IDs - prefer existing n8n credentials over hardcoded map
    node_name = node.get('name', '')
    node_type = node.get('type', '')

    # Strategy 1: Use EXISTING credentials from the live n8n workflow (best - preserves auth)
    if node_name in existing_creds:
        node['credentials'] = existing_creds[node_name]
    elif '__type__' + node_type in existing_creds:
        node['credentials'] = existing_creds['__type__' + node_type]
    else:
        # Strategy 2: Fallback to hardcoded credential map
        credentials = node.get('credentials', {})
        for cred_type, cred_info in credentials.items():
            if isinstance(cred_info, dict):
                cred_name = cred_info.get('name', '')
                cred_id = cred_info.get('id', '')
                if 'REPLACE_WITH' in cred_id or cred_name in cred_map:
                    new_id = cred_map.get(cred_name) or cred_map.get(cred_type)
                    if new_id:
                        node['credentials'][cred_type]['id'] = new_id

# Remove read-only fields for PUT request
for field in ['active', 'id', 'createdAt', 'updatedAt', 'versionId',
              'triggerCount', 'sharedWithProjects', 'homeProject', 'tags',
              'meta', 'pinData', 'staticData']:
    workflow.pop(field, None)

# Ensure nodes and connections exist
if 'nodes' not in workflow:
    workflow['nodes'] = []
if 'connections' not in workflow:
    workflow['connections'] = {}
if 'settings' not in workflow:
    workflow['settings'] = {}

print(json.dumps(workflow))
PYEOF
}

# Fetch a single workflow's full detail from n8n API
fetch_workflow_detail() {
    local workflow_id="$1"
    curl -s -H "X-N8N-API-KEY: $N8N_API_KEY" \
        "$N8N_API_URL/api/v1/workflows/$workflow_id" 2>/dev/null
}

# MERGE backup into existing workflow: only update code/queries, preserve credentials
merge_backup_into_existing() {
    local backup_file="$1"
    local existing_json="$2"

    export BACKUP_FILE="$backup_file"
    export EXISTING_JSON="$existing_json"
    python3 << 'PYEOF'
import json, os, sys

backup_file = os.environ.get('BACKUP_FILE', '')
existing_json_str = os.environ.get('EXISTING_JSON', '{}')

with open(backup_file, 'r') as f:
    backup = json.load(f)

existing = json.loads(existing_json_str)

# Build lookup: backup nodes by name
backup_nodes_by_name = {}
for node in backup.get('nodes', []):
    backup_nodes_by_name[node.get('name', '')] = node

# Track changes
changes = []

# Update existing nodes with backup code/queries ONLY
for node in existing.get('nodes', []):
    node_name = node.get('name', '')
    node_type = node.get('type', '')
    backup_node = backup_nodes_by_name.get(node_name)

    if not backup_node:
        continue

    # For Code nodes: update jsCode only
    if node_type == 'n8n-nodes-base.code':
        backup_params = backup_node.get('parameters', {})
        existing_params = node.get('parameters', {})
        backup_code = backup_params.get('jsCode', backup_params.get('code', ''))
        existing_code = existing_params.get('jsCode', existing_params.get('code', ''))
        if backup_code and backup_code != existing_code:
            existing_params['jsCode'] = backup_code
            # Remove old 'code' key if present
            existing_params.pop('code', None)
            changes.append(f"Code updated: {node_name}")

    # For Postgres nodes: update query only
    elif node_type == 'n8n-nodes-base.postgres':
        backup_params = backup_node.get('parameters', {})
        existing_params = node.get('parameters', {})
        backup_query = backup_params.get('query', '')
        existing_query = existing_params.get('query', '')
        if backup_query and backup_query != existing_query:
            existing_params['query'] = backup_query
            changes.append(f"Query updated: {node_name}")

    # For Webhook nodes: update path/method if different
    elif node_type == 'n8n-nodes-base.webhook':
        backup_params = backup_node.get('parameters', {})
        existing_params = node.get('parameters', {})
        for key in ['path', 'httpMethod', 'responseMode']:
            if key in backup_params:
                existing_params[key] = backup_params[key]

    # For IF nodes: update conditions
    elif node_type == 'n8n-nodes-base.if':
        backup_params = backup_node.get('parameters', {})
        existing_params = node.get('parameters', {})
        if 'conditions' in backup_params:
            existing_params['conditions'] = backup_params['conditions']

    # For Respond nodes: update response config
    elif node_type == 'n8n-nodes-base.respondToWebhook':
        backup_params = backup_node.get('parameters', {})
        existing_params = node.get('parameters', {})
        for key in ['respondWith', 'responseBody', 'responseCode']:
            if key in backup_params:
                existing_params[key] = backup_params[key]

    # NEVER touch: credentials, position, id, typeVersion, etc.

# Build credential map from existing n8n nodes (type -> credentials)
# This allows us to assign correct credential IDs to new nodes from backup
existing_creds_by_type = {}
existing_creds_by_name = {}
for node in existing.get('nodes', []):
    node_creds = node.get('credentials', {})
    if node_creds:
        existing_creds_by_name[node.get('name', '')] = node_creds
        for cred_type in node_creds:
            existing_creds_by_type[cred_type] = node_creds[cred_type]

# Add new nodes from backup that don't exist in current workflow
existing_names = {n.get('name', '') for n in existing.get('nodes', [])}
for node_name, backup_node in backup_nodes_by_name.items():
    if node_name not in existing_names:
        # Fix credentials on new nodes: map backup cred IDs to real n8n instance IDs
        new_node_creds = backup_node.get('credentials', {})
        if new_node_creds:
            for cred_type, cred_info in new_node_creds.items():
                if isinstance(cred_info, dict) and cred_type in existing_creds_by_type:
                    # Use the real credential from existing n8n workflow
                    backup_node['credentials'][cred_type] = existing_creds_by_type[cred_type]
                    changes.append(f"  Credential mapped: {cred_type} -> {existing_creds_by_type[cred_type].get('id', '?')}")
        existing['nodes'].append(backup_node)
        changes.append(f"New node added: {node_name}")

# Update connections from backup (needed if new nodes were added or renamed)
if backup.get('connections'):
    existing['connections'] = backup['connections']

# WHITELIST: only keep fields that n8n PUT /workflows/{id} accepts
allowed_fields = {'name', 'nodes', 'connections', 'settings'}
keys_to_remove = [k for k in existing.keys() if k not in allowed_fields]
for k in keys_to_remove:
    del existing[k]

# Output changes to stderr for logging
for c in changes:
    print(f"  MERGE: {c}", file=sys.stderr)
if not changes:
    print("  MERGE: No changes detected", file=sys.stderr)

print(json.dumps(existing))
PYEOF
}

# Update workflow via n8n API
update_workflow() {
    local workflow_id="$1"
    local workflow_json="$2"
    local workflow_name="$3"

    log "INFO" "Updating workflow: $workflow_name (ID: $workflow_id)"

    # Write JSON to temp file to avoid argument length limits
    local tmpfile="/tmp/n8n_update_$$.json"
    echo "$workflow_json" > "$tmpfile"

    # Send PUT request using file
    local response
    response=$(curl -s -w "\n%{http_code}" -X PUT \
        -H "X-N8N-API-KEY: $N8N_API_KEY" \
        -H "Content-Type: application/json" \
        -d @"$tmpfile" \
        "$N8N_API_URL/api/v1/workflows/$workflow_id" 2>&1)

    rm -f "$tmpfile"

    local http_code
    http_code=$(echo "$response" | tail -1)
    local body
    body=$(echo "$response" | sed '$d')

    if [ "$http_code" -eq 200 ]; then
        log "SUCCESS" "Workflow updated successfully: $workflow_name"
        return 0
    else
        local error_msg
        error_msg=$(echo "$body" | python3 -c "import sys, json; print(json.load(sys.stdin).get('message', 'Unknown error'))" 2>/dev/null || echo "Unknown error")
        log "ERROR" "Failed to update workflow: $workflow_name (HTTP $http_code) - $error_msg"
        return 1
    fi
}

# Deactivate workflow (to force webhook re-registration on activate)
deactivate_workflow() {
    local workflow_id="$1"
    local workflow_name="$2"

    curl -s -X POST \
        -H "X-N8N-API-KEY: $N8N_API_KEY" \
        -H "Content-Type: application/json" \
        "$N8N_API_URL/api/v1/workflows/$workflow_id/deactivate" > /dev/null 2>&1
    # Delay to let n8n clean up webhook registrations
    sleep 0.5
}

# Activate workflow
activate_workflow() {
    local workflow_id="$1"
    local workflow_name="$2"

    log "INFO" "Activating workflow: $workflow_name"

    local response
    response=$(curl -s -w "\n%{http_code}" -X POST \
        -H "X-N8N-API-KEY: $N8N_API_KEY" \
        -H "Content-Type: application/json" \
        "$N8N_API_URL/api/v1/workflows/$workflow_id/activate" 2>&1)

    local http_code
    http_code=$(echo "$response" | tail -1)

    if [ "$http_code" -eq 200 ]; then
        log "SUCCESS" "Workflow activated: $workflow_name"
        sleep 0.5  # Delay for webhook registration
        return 0
    else
        local error_msg
        error_msg=$(echo "$response" | sed '$d' | python3 -c "import sys, json; print(json.load(sys.stdin).get('message', 'Unknown error'))" 2>/dev/null || echo "Unknown error")
        log "WARN" "Failed to activate workflow: $workflow_name (HTTP $http_code) - $error_msg"
        return 0  # Don't fail the whole process
    fi
}

# Process a single workflow using MERGE strategy
# 1. GET existing workflow from n8n (with credentials intact)
# 2. MERGE only code/queries from backup into existing
# 3. PUT merged result (credentials untouched)
process_workflow() {
    local backup_file="$1"
    local relative_path="${backup_file#$BACKUP_DIR/}"

    TOTAL_WORKFLOWS=$((TOTAL_WORKFLOWS + 1))

    log "INFO" "Processing: $relative_path"

    # Extract webhook path from filename
    local filename
    filename=$(basename "$backup_file" .json)

    # Try to find workflow with matching webhook path
    local workflow_id
    workflow_id=$(find_workflow_by_webhook "$filename")

    if [ -z "$workflow_id" ]; then
        log "WARN" "No existing workflow found with webhook path: $filename (skipping)"
        SKIPPED_WORKFLOWS=$((SKIPPED_WORKFLOWS + 1))
        return 1
    fi

    log "INFO" "Found existing workflow ID: $workflow_id"

    # Validate backup JSON
    if ! python3 -m json.tool "$backup_file" > /dev/null 2>&1; then
        log "ERROR" "Invalid JSON in backup file: $backup_file"
        FAILED_UPDATES=$((FAILED_UPDATES + 1))
        return 1
    fi

    # GET the full existing workflow from n8n (credentials, positions, everything)
    local existing_workflow
    existing_workflow=$(fetch_workflow_detail "$workflow_id")

    if [ -z "$existing_workflow" ] || ! echo "$existing_workflow" | python3 -m json.tool > /dev/null 2>&1; then
        log "ERROR" "Failed to fetch existing workflow $workflow_id from n8n"
        FAILED_UPDATES=$((FAILED_UPDATES + 1))
        return 1
    fi

    log "INFO" "Fetched existing workflow from n8n (credentials preserved)"

    # MERGE: update ONLY code/queries from backup, keep everything else from n8n
    local merged_json
    merged_json=$(merge_backup_into_existing "$backup_file" "$existing_workflow" 2>> "$LOG_FILE")

    if [ -z "$merged_json" ]; then
        log "ERROR" "Failed to merge backup for: $relative_path"
        FAILED_UPDATES=$((FAILED_UPDATES + 1))
        return 1
    fi

    # DEBUG: Log credentials being sent in the PUT
    log "INFO" "Credentials in PUT body for $filename:"
    echo "$merged_json" | python3 -c "
import json, sys
data = json.load(sys.stdin)
for node in data.get('nodes', []):
    creds = node.get('credentials', {})
    if creds:
        for ctype, cval in creds.items():
            print(f'  {node[\"name\"]} | {ctype} | id={cval.get(\"id\",\"NONE\")} | name={cval.get(\"name\",\"NONE\")}')
    else:
        ntype = node.get('type','')
        if 'webhook' not in ntype and 'code' not in ntype and 'if' not in ntype and 'respond' not in ntype and 'noOp' not in ntype and 'set' not in ntype:
            print(f'  ⚠️  {node[\"name\"]} ({ntype}) → NO CREDENTIALS')
" 2>&1 | tee -a "$LOG_FILE"

    # NO deactivate/activate cycle! Just PUT the merged JSON.
    # The workflow stays active, webhooks stay registered, credentials stay intact.
    if update_workflow "$workflow_id" "$merged_json" "$filename"; then
        # DEBUG: Verify credentials after PUT
        log "INFO" "Verifying credentials AFTER PUT for $filename:"
        local after_json
        after_json=$(fetch_workflow_detail "$workflow_id")
        echo "$after_json" | python3 -c "
import json, sys
data = json.load(sys.stdin)
for node in data.get('nodes', []):
    creds = node.get('credentials', {})
    if creds:
        for ctype, cval in creds.items():
            print(f'  ✅ {node[\"name\"]} | {ctype} | id={cval.get(\"id\",\"NONE\")}')
" 2>&1 | tee -a "$LOG_FILE"
        SUCCESSFUL_UPDATES=$((SUCCESSFUL_UPDATES + 1))
        return 0
    else
        FAILED_UPDATES=$((FAILED_UPDATES + 1))
        return 1
    fi
}

# Main execution
main() {
    header "N8N Workflow Reimporter - TalosPrimes"

    # Handle command-line arguments
    if [ $# -gt 0 ]; then
        N8N_API_KEY="$1"
        export N8N_API_KEY
    fi
    if [ $# -gt 1 ]; then
        N8N_API_URL="$2"
        export N8N_API_URL
    fi

    # Set defaults
    N8N_API_URL="${N8N_API_URL:-http://localhost:5678}"

    log "INFO" "Starting workflow reimport process..."
    log "INFO" "Log file: $LOG_FILE"
    log "INFO" "Backup directory: $BACKUP_DIR"
    log "INFO" "n8n API URL: $N8N_API_URL"

    # Validation
    header "Pre-flight Checks"
    validate_tools || exit 1
    load_api_key || exit 1
    validate_n8n_connection || exit 1

    # Get all existing workflows
    header "Fetching Existing Workflows"
    fetch_all_workflows || exit 1

    # Auto-discover ALL workflow JSON files in backup directory
    header "Processing Workflows"
    log "INFO" "Auto-discovering all workflow JSON files in $BACKUP_DIR..."

    local workflow_count=0
    while IFS= read -r -d '' backup_file; do
        # Skip non-workflow files (e.g., Super-Agent mega-workflow)
        local filename
        filename=$(basename "$backup_file" .json)
        if [[ "$filename" == "Super-Agent"* ]] || [[ "$filename" == "auto-publish"* ]]; then
            log "INFO" "Skipping non-webhook workflow: $filename"
            continue
        fi

        workflow_count=$((workflow_count + 1))
        process_workflow "$backup_file"
        echo "" | tee -a "$LOG_FILE"
    done < <(find "$BACKUP_DIR" -name "*.json" -type f -print0 | sort -z)

    log "INFO" "Discovered $workflow_count workflow files"

    # Summary
    header "Summary"
    log "INFO" "Total workflows processed: $TOTAL_WORKFLOWS"
    log "SUCCESS" "Successful updates: $SUCCESSFUL_UPDATES"
    log "ERROR" "Failed updates: $FAILED_UPDATES"
    log "WARN" "Skipped workflows: $SKIPPED_WORKFLOWS"

    echo "" | tee -a "$LOG_FILE"

    if [ $FAILED_UPDATES -eq 0 ]; then
        log "SUCCESS" "✅ All workflows reimported successfully!"
        return 0
    else
        log "WARN" "⚠️  Some workflows failed to reimport. Check log: $LOG_FILE"
        return 1
    fi
}

# Run main function
main "$@"
